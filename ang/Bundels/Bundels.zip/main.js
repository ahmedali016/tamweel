(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/addclient/addclient.component.html":
/*!****************************************************!*\
  !*** ./src/app/addclient/addclient.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = " <div class=\"wrapper\">\n      \n      <header class=\"main-header\">\n        <!-- Logo -->\n        <a href=\"index2.html\" class=\"logo\"><b>Admin</b>LTE</a>\n        <!-- Header Navbar: style can be found in header.less -->\n        <nav class=\"navbar navbar-static-top\" role=\"navigation\">\n          <!-- Sidebar toggle button-->\n          <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">\n            <span class=\"sr-only\">Toggle navigation</span>\n          </a>\n          <div class=\"navbar-custom-menu\">\n            <ul class=\"nav navbar-nav\">\n              <!-- Messages: style can be found in dropdown.less-->\n              <li class=\"dropdown messages-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <i class=\"fa fa-envelope-o\"></i>\n                  <span class=\"label label-success\">4</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <li class=\"header\">You have 4 messages</li>\n                  <li>\n                    <!-- inner menu: contains the actual data -->\n                    <ul class=\"menu\">\n                      <li><!-- start message -->\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\"/>\n                          </div>\n                          <h4>\n                            Support Team\n                            <small><i class=\"fa fa-clock-o\"></i> 5 mins</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li><!-- end message -->\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user3-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            AdminLTE Design Team\n                            <small><i class=\"fa fa-clock-o\"></i> 2 hours</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user4-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            Developers\n                            <small><i class=\"fa fa-clock-o\"></i> Today</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user3-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            Sales Department\n                            <small><i class=\"fa fa-clock-o\"></i> Yesterday</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user4-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            Reviewers\n                            <small><i class=\"fa fa-clock-o\"></i> 2 days</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                    </ul>\n                  </li>\n                  <li class=\"footer\"><a href=\"#\">See All Messages</a></li>\n                </ul>\n              </li>\n              <!-- Notifications: style can be found in dropdown.less -->\n              <li class=\"dropdown notifications-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <i class=\"fa fa-bell-o\"></i>\n                  <span class=\"label label-warning\">10</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <li class=\"header\">You have 10 notifications</li>\n                  <li>\n                    <!-- inner menu: contains the actual data -->\n                    <ul class=\"menu\">\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-users text-aqua\"></i> 5 new members joined today\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-warning text-yellow\"></i> Very long description here that may not fit into the page and may cause design problems\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-users text-red\"></i> 5 new members joined\n                        </a>\n                      </li>\n\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-shopping-cart text-green\"></i> 25 sales made\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-user text-red\"></i> You changed your username\n                        </a>\n                      </li>\n                    </ul>\n                  </li>\n                  <li class=\"footer\"><a href=\"#\">View all</a></li>\n                </ul>\n              </li>\n              <!-- Tasks: style can be found in dropdown.less -->\n              <li class=\"dropdown tasks-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <i class=\"fa fa-flag-o\"></i>\n                  <span class=\"label label-danger\">9</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <li class=\"header\">You have 9 tasks</li>\n                  <li>\n                    <!-- inner menu: contains the actual data -->\n                    <ul class=\"menu\">\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Design some buttons\n                            <small class=\"pull-right\">20%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-aqua\" style=\"width: 20%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">20% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Create a nice theme\n                            <small class=\"pull-right\">40%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-green\" style=\"width: 40%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">40% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Some task I need to do\n                            <small class=\"pull-right\">60%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-red\" style=\"width: 60%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">60% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Make beautiful transitions\n                            <small class=\"pull-right\">80%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-yellow\" style=\"width: 80%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">80% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                    </ul>\n                  </li>\n                  <li class=\"footer\">\n                    <a href=\"#\">View all tasks</a>\n                  </li>\n                </ul>\n              </li>\n              <!-- User Account: style can be found in dropdown.less -->\n              <li class=\"dropdown user user-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <img src=\"dist/img/user2-160x160.jpg\" class=\"user-image\" alt=\"User Image\"/>\n                  <span class=\"hidden-xs\">Alexander Pierce</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <!-- User image -->\n                  <li class=\"user-header\">\n                    <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\" />\n                    <p>\n                      Alexander Pierce - Web Developer\n                      <small>Member since Nov. 2012</small>\n                    </p>\n                  </li>\n                  <!-- Menu Body -->\n                  <li class=\"user-body\">\n                    <div class=\"col-xs-4 text-center\">\n                      <a href=\"#\">Followers</a>\n                    </div>\n                    <div class=\"col-xs-4 text-center\">\n                      <a href=\"#\">Sales</a>\n                    </div>\n                    <div class=\"col-xs-4 text-center\">\n                      <a href=\"#\">Friends</a>\n                    </div>\n                  </li>\n                  <!-- Menu Footer-->\n                  <li class=\"user-footer\">\n                    <div class=\"pull-left\">\n                      <a href=\"#\" class=\"btn btn-default btn-flat\">Profile</a>\n                    </div>\n                    <div class=\"pull-right\">\n                      <a href=\"#\" class=\"btn btn-default btn-flat\">Sign out</a>\n                    </div>\n                  </li>\n                </ul>\n              </li>\n            </ul>\n          </div>\n        </nav>\n      </header>\n      <!-- Left side column. contains the logo and sidebar -->\n      <aside class=\"main-sidebar\">\n        <!-- sidebar: style can be found in sidebar.less -->\n        <section class=\"sidebar\">\n          <!-- Sidebar user panel -->\n          <div class=\"user-panel\">\n            <div class=\"pull-left image\">\n              <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\" />\n            </div>\n            <div class=\"pull-left info\">\n              <p>Alexander Pierce</p>\n\n              <a href=\"#\"><i class=\"fa fa-circle text-success\"></i> Online</a>\n            </div>\n          </div>\n          <!-- search form -->\n          <form action=\"#\" method=\"get\" class=\"sidebar-form\">\n            <div class=\"input-group\">\n              <input type=\"text\" name=\"q\" class=\"form-control\" placeholder=\"Search...\"/>\n              <span class=\"input-group-btn\">\n                <button type='submit' name='search' id='search-btn' class=\"btn btn-flat\"><i class=\"fa fa-search\"></i></button>\n              </span>\n            </div>\n          </form>\n          <!-- /.search form -->\n          <!-- sidebar menu: : style can be found in sidebar.less -->\n          <ul class=\"sidebar-menu\">\n            <li class=\"header\">MAIN NAVIGATION</li>\n                       \n            <li>\n              <a routerLink=\"/jobtitle\">\n                <i class=\"fa fa-th\"></i> <span>Job Title</span> \n              </a>\n            </li>\n            <li>\n              <a routerLink=\"/department\">\n                <i class=\"fa fa-envelope\"></i> <span>Department</span>                \n              </a>\n            </li>        \n            \n            <li>\n              <a routerLink=\"/client\">\n                <i class=\"fa fa-calendar\"></i> <span>Client</span>\n              </a>\n            </li>\n            <li>\n              <a routerLink=\"/addclient\">\n                <i class=\"fa fa-calendar\"></i> <span>Add Client</span>\n              </a>\n            </li>\n           \n           \n           \n          </ul>\n        </section>\n        <!-- /.sidebar -->\n      </aside>\n\n      <!-- Right side column. Contains the navbar and content of the page -->\n      <div class=\"content-wrapper\">\n        <!-- Content Header (Page header) -->\n        <section class=\"content-header\">\n          <h1>\n            Dashboard\n            <small>Control panel</small>\n          </h1>\n          <ol class=\"breadcrumb\">\n            <li><a href=\"#\"><i class=\"fa fa-dashboard\"></i> Home</a></li>\n            <li class=\"active\">Dashboard</li>\n          </ol>\n        </section>\n\n        <!-- Main content -->\n        <section class=\"content\">\n          <!-- Small boxes (Stat box) -->\n          <div class=\"row\">\n             <form role=\"form\">\n            <!-- left column -->\n              <div class=\"col-md-6\">\n                <!-- general form elements -->\n                <div class=\"box box-primary\">\n                  <div class=\"box-header\">\n                    <h3 class=\"box-title\">Add Job title</h3>\n                  </div><!-- /.box-header -->\n                  <!-- form start -->\n                \n                    <div class=\"box-body\">\n                      <div class=\"form-group\">\n                        <label for=\"nametxt\">Full name</label>\n                        <input #nametxt type=\"text\" class=\"form-control\"  placeholder=\"Full name\">\n                      </div>\n                      <div class=\"form-group\">\n                        <label for=\"birthdate\">Birth date</label>\n                        <input #birthdate type=\"date\" class=\"form-control\"  placeholder=\"Birth date\">\n                      </div>\n                      <div class=\"form-group\">\n                        <label for=\"mailtxt\">E-mail Address</label>\n                        <input #mailtxt type=\"email\" class=\"form-control\"  placeholder=\"E-mail Address\">\n                      </div>\n                      <div class=\"form-group\">\n                      <label>Department</label>\n                      <select #depart class=\"form-control\" >\n                               <option *ngFor=\"let d of departdata\" value=\"{{d.depaId}}\">{{d.departmentName}}</option>               \n                      </select>\n                      </div>\n                      <div class=\"form-group\">\n                            <label>Job title</label>\n                            <select #job class=\"form-control\" >\n                                 <option *ngFor=\"let j of jobdata\" value=\"{{j.jobId}}\">{{j.jobTitle}}</option>                  \n                            </select>\n                      </div>\n                      <div class=\"form-group\">\n                        <label for=\"passtxt\">Password</label>\n                        <input #passtxt type=\"password\" class=\"form-control\"  placeholder=\"Password\">\n                      </div>\n                      <div class=\"form-group\">\n                        <label for=\"confirmpasstxt\">Confirm password</label>\n                        <input #confirmpasstxt type=\"password\" class=\"form-control\"  placeholder=\"Confirm password\">\n                      </div>\n                      <div class=\"form-group\">\n                        <label for=\"exampleInputFile\">Image</label>\n                        <input #img type=\"file\" id=\"exampleInputFile\" (change)=\"handleFileInput($event.target.files)\">\n                        <p class=\"help-block\"></p>\n                      </div>\n                    </div><!-- /.box-body -->\n  \n                    <div class=\"box-footer\">\n                      <button type=\"button\" class=\"btn btn-primary\" (click)=\"AddClient(nametxt.value,birthdate.value,mailtxt.value,\n                              depart.value,job.value,passtxt.value,confirmpasstxt.value,img.value)\">Submit</button>\n                    </div>\n                \n                </div><!-- /.box -->\n            \n                <!-- Input addon -->\n                  \n              </div><!--/.col (left) -->\n              \n              <div class=\"col-md-6\">\n                <div class=\"nav-tabs-custom\">\n                <ul class=\"nav nav-tabs\">\n                  <li class=\"active\"><a href=\"#tab_1\" data-toggle=\"tab\">Phone</a></li>\n                  <li><a href=\"#tab_2\" data-toggle=\"tab\">Address</a></li>\n                                    \n                </ul>\n                <div class=\"tab-content\">\n                  <div class=\"tab-pane active\" id=\"tab_1\">\n                    <div class=\"input-group input-group-sm\">\n                      <input #phone type=\"text\" class=\"form-control\">\n                      <span class=\"input-group-btn\">\n                      <button class=\"btn btn-info btn-flat\" type=\"button\" (click)=\"AddPhone(phone.value);phone.value=''\">Add</button>\n                      </span>\n                     </div>\n                    <div class=\"box\">\n                      <div class=\"box-header\">\n                        <h3 class=\"box-title\"></h3>\n                      </div><!-- /.box-header -->\n                      <div class=\"box-body no-padding\">\n                        <table class=\"table table-condensed\">\n                          <tbody>\n                          <tr >\n                            <th>Phone</th>\n                            <th>Delete</th>                      \n                          </tr>\n                          <tr *ngFor=\"let ph of phonenum ; let i = index\">\n                            <td>{{ph}}</td>\n                            <td><button type=\"button\" (click)=\"DelPhone(i)\">X</button></td>                      \n                          </tr>\n                        </tbody></table>\n                      </div><!-- /.box-body -->\n                    </div>\n                  </div><!-- /.tab-pane -->\n                  <div class=\"tab-pane\" id=\"tab_2\">\n                    <div class=\"input-group input-group-sm\">\n                      <input #addresstxt type=\"text\" class=\"form-control\">\n                      <span class=\"input-group-btn\">\n                      <button class=\"btn btn-info btn-flat\" type=\"button\" (click)=\"AddAddress(addresstxt.value);addresstxt.value=''\">Add</button>\n                      </span>\n                     </div>\n                    <div class=\"box\">\n                      <div class=\"box-header\">\n                        <h3 class=\"box-title\"></h3>\n                      </div><!-- /.box-header -->\n                      <div class=\"box-body no-padding\">\n                        <table class=\"table table-condensed\">\n                          <tbody><tr>\n                            <th >Address</th>\n                            <th>Delete</th>                      \n                          </tr>\n                          <tr *ngFor=\"let ad of adders ; let i = index\">\n                            <td>{{ad}}</td>\n                            <td><button type=\"button\" (click)=\"DelAddress(i)\">X</button></td>                      \n                          </tr>\n                        </tbody></table>\n                      </div><!-- /.box-body -->\n                    </div>\n                  </div><!-- /.tab-pane -->\n                </div><!-- /.tab-content -->\n              </div>\n              </div>\n            <!-- right column -->\n             </form>  \n          </div>\n         \n           \n          \n        </section><!-- /.content -->\n      </div><!-- /.content-wrapper -->\n      <footer class=\"main-footer\">\n        <div class=\"pull-right hidden-xs\">\n          <b>Version</b> 2.0\n        </div>\n        <strong>Copyright &copy; 2014-2015 <a href=\"http://almsaeedstudio.com\">Almsaeed Studio</a>.</strong> All rights reserved.\n      </footer>\n    </div><!-- ./wrapper -->\n"

/***/ }),

/***/ "./src/app/addclient/addclient.component.scss":
/*!****************************************************!*\
  !*** ./src/app/addclient/addclient.component.scss ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkZGNsaWVudC9hZGRjbGllbnQuY29tcG9uZW50LnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/addclient/addclient.component.ts":
/*!**************************************************!*\
  !*** ./src/app/addclient/addclient.component.ts ***!
  \**************************************************/
/*! exports provided: AddclientComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddclientComponent", function() { return AddclientComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _client_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../client-api.service */ "./src/app/client-api.service.ts");
/* harmony import */ var _job_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../job-api.service */ "./src/app/job-api.service.ts");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");





var AddclientComponent = /** @class */ (function () {
    function AddclientComponent(api, jobapi, departapi) {
        this.api = api;
        this.jobapi = jobapi;
        this.departapi = departapi;
        this.phonenum = [];
        this.adders = [];
        this.jobdata = [];
        this.fileToUpload = null;
    }
    AddclientComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.departapi.getDepartment()
            .subscribe(function (res) { _this.departdata = res; console.log(_this.departdata); }, function (err) { console.log(err); });
        this.jobapi.getjobs().subscribe(function (res) { _this.jobdata = res; });
    };
    AddclientComponent.prototype.handleFileInput = function (files) {
        this.fileToUpload = files.item(0);
    };
    AddclientComponent.prototype.AddClient = function (name, birthdate, mail, department, job, pass, conf, img) {
        var formData = new FormData();
        formData.append('name', name);
        formData.append('birth', birthdate);
        formData.append('mail', mail);
        formData.append('department', department);
        formData.append('job', job);
        formData.append('pass', pass);
        formData.append('phones', JSON.stringify(this.phonenum));
        formData.append('addresses', JSON.stringify(this.adders));
        formData.append('file', this.fileToUpload);
        console.log(conf);
        console.log(this.fileToUpload);
        this.api.addClient(formData).subscribe();
    };
    AddclientComponent.prototype.AddPhone = function (phone) {
        if (phone > 0)
            this.phonenum.push(phone);
    };
    AddclientComponent.prototype.DelPhone = function (index) {
        this.phonenum.pop();
    };
    AddclientComponent.prototype.AddAddress = function (address) {
        this.adders.push(address);
    };
    AddclientComponent.prototype.DelAddress = function (index) {
        this.adders.pop();
    };
    AddclientComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-addclient',
            template: __webpack_require__(/*! ./addclient.component.html */ "./src/app/addclient/addclient.component.html"),
            styles: [__webpack_require__(/*! ./addclient.component.scss */ "./src/app/addclient/addclient.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_client_api_service__WEBPACK_IMPORTED_MODULE_2__["ClientApiService"], _job_api_service__WEBPACK_IMPORTED_MODULE_3__["JobApiService"], _api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"]])
    ], AddclientComponent);
    return AddclientComponent;
}());



/***/ }),

/***/ "./src/app/api.service.ts":
/*!********************************!*\
  !*** ./src/app/api.service.ts ***!
  \********************************/
/*! exports provided: ApiService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiService", function() { return ApiService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");





var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var apiUrl = '../api/department';
//const apiUrl = 'http://localhost:51195/api/department';
var ApiService = /** @class */ (function () {
    function ApiService(http) {
        this.http = http;
    }
    ApiService.prototype.getDepartment = function () {
        return this.http.get(apiUrl)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (heroes) { return console.log('fetched departments'); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError('getDepartment', [])));
    };
    ApiService.prototype.addDepart = function (depart) {
        //this.http.post(apiUrl, depart, httpOptions).subscribe(response => {x=response});
        //this.http.post<Department[]>(apiUrl, depart, httpOptions).pipe(catchError(this.handleError('addDepart', depart)));
        return this.http.post(apiUrl, depart, httpOptions);
    };
    ApiService.prototype.deleteDepart = function (id) {
        var url = apiUrl + "/" + id;
        //this.http.delete(url, httpOptions).subscribe(response => console.log(response));
        return this.http.delete(url, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError('deleteDepart')));
    };
    ApiService.prototype.EditDepart = function (depart) {
        //this.http.put(apiUrl,depart,httpOptions).subscribe(response=>console.log(response));
        return this.http.put(apiUrl, depart, httpOptions);
    };
    ApiService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // Let the app keep running by returning an empty result.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(result);
        };
    };
    ApiService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]])
    ], ApiService);
    return ApiService;
}());



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _login_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.component */ "./src/app/login.component.ts");
/* harmony import */ var _registerform_registerform_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./registerform/registerform.component */ "./src/app/registerform/registerform.component.ts");
/* harmony import */ var _client_client_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./client/client.component */ "./src/app/client/client.component.ts");
/* harmony import */ var _addclient_addclient_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./addclient/addclient.component */ "./src/app/addclient/addclient.component.ts");
/* harmony import */ var _editclient_editclient_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./editclient/editclient.component */ "./src/app/editclient/editclient.component.ts");
/* harmony import */ var _departments_departments_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./departments/departments.component */ "./src/app/departments/departments.component.ts");
/* harmony import */ var _job_title_job_title_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./job-title/job-title.component */ "./src/app/job-title/job-title.component.ts");










var routes = [{ path: 'login', component: _login_component__WEBPACK_IMPORTED_MODULE_3__["LoginComponent"] },
    { path: 'register', component: _registerform_registerform_component__WEBPACK_IMPORTED_MODULE_4__["RegisterformComponent"] },
    { path: 'department', component: _departments_departments_component__WEBPACK_IMPORTED_MODULE_8__["DepartmentsComponent"] },
    { path: 'jobtitle', component: _job_title_job_title_component__WEBPACK_IMPORTED_MODULE_9__["JobTitleComponent"] },
    { path: 'client', component: _client_client_component__WEBPACK_IMPORTED_MODULE_5__["ClientComponent"] },
    { path: 'addclient', component: _addclient_addclient_component__WEBPACK_IMPORTED_MODULE_6__["AddclientComponent"] },
    { path: 'editclient/:id', component: _editclient_editclient_component__WEBPACK_IMPORTED_MODULE_7__["EditclientComponent"] }];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--The content below is only a placeholder and can be replaced.-->\r\n\r\n<!--<h1>{{title}}</h1>\r\n<nav>\r\n  <a routerLink=\"/hero\">Heroes</a>\r\n  <a routerLink=\"/log\">log</a><br/>\r\n  <a routerLink=\"/department\">department</a>\r\n</nav>-->\r\n<router-outlet></router-outlet>\r\n"

/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var AppComponent = /** @class */ (function () {
    function AppComponent(router) {
        this.router = router;
        this.title = 'one page';
    }
    AppComponent.prototype.ngOnInit = function () {
        this.router.navigate(['/login']);
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _login_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./login.component */ "./src/app/login.component.ts");
/* harmony import */ var _departments_departments_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./departments/departments.component */ "./src/app/departments/departments.component.ts");
/* harmony import */ var _job_title_job_title_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./job-title/job-title.component */ "./src/app/job-title/job-title.component.ts");
/* harmony import */ var _client_client_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./client/client.component */ "./src/app/client/client.component.ts");
/* harmony import */ var _registerform_registerform_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./registerform/registerform.component */ "./src/app/registerform/registerform.component.ts");
/* harmony import */ var _addclient_addclient_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./addclient/addclient.component */ "./src/app/addclient/addclient.component.ts");
/* harmony import */ var _editclient_editclient_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./editclient/editclient.component */ "./src/app/editclient/editclient.component.ts");














var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"],
                _login_component__WEBPACK_IMPORTED_MODULE_7__["LoginComponent"],
                _departments_departments_component__WEBPACK_IMPORTED_MODULE_8__["DepartmentsComponent"],
                _job_title_job_title_component__WEBPACK_IMPORTED_MODULE_9__["JobTitleComponent"],
                _client_client_component__WEBPACK_IMPORTED_MODULE_10__["ClientComponent"],
                _registerform_registerform_component__WEBPACK_IMPORTED_MODULE_11__["RegisterformComponent"],
                _addclient_addclient_component__WEBPACK_IMPORTED_MODULE_12__["AddclientComponent"],
                _editclient_editclient_component__WEBPACK_IMPORTED_MODULE_13__["EditclientComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_5__["AppRoutingModule"],
            ],
            providers: [],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/client-api.service.ts":
/*!***************************************!*\
  !*** ./src/app/client-api.service.ts ***!
  \***************************************/
/*! exports provided: ClientApiService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientApiService", function() { return ClientApiService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");





var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var apiUrl = '../api/Clients';
//const apiUrl = 'http://localhost:51195/api/Clients';
var ClientApiService = /** @class */ (function () {
    function ClientApiService(http) {
        this.http = http;
    }
    ClientApiService.prototype.getClient = function () {
        return this.http.get(apiUrl).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (clin) { return console.log('fetched clients'); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError('getDepartment', [])));
    };
    ClientApiService.prototype.addClient = function (frm) {
        console.log(frm);
        //this.http.post(apiUrl,frm,httpOptions).subscribe();
        return this.http.post(apiUrl, frm);
    };
    ClientApiService.prototype.deleteClient = function (id) {
        var url = apiUrl + "/" + id;
        return this.http.delete(url, httpOptions);
    };
    ClientApiService.prototype.getClientData = function (id) {
        var url = apiUrl + "/" + id;
        return this.http.get(url, httpOptions);
    };
    ClientApiService.prototype.editClient = function (frm) {
        return this.http.put(apiUrl, frm);
    };
    ClientApiService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // Let the app keep running by returning an empty result.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(result);
        };
    };
    ClientApiService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]])
    ], ClientApiService);
    return ClientApiService;
}());



/***/ }),

/***/ "./src/app/client/client.component.html":
/*!**********************************************!*\
  !*** ./src/app/client/client.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = " <div class=\"wrapper\">\n      \n      <header class=\"main-header\">\n        <!-- Logo -->\n        <a href=\"index2.html\" class=\"logo\"><b>Admin</b>LTE</a>\n        <!-- Header Navbar: style can be found in header.less -->\n        <nav class=\"navbar navbar-static-top\" role=\"navigation\">\n          <!-- Sidebar toggle button-->\n          <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">\n            <span class=\"sr-only\">Toggle navigation</span>\n          </a>\n          <div class=\"navbar-custom-menu\">\n            <ul class=\"nav navbar-nav\">\n              <!-- Messages: style can be found in dropdown.less-->\n              <li class=\"dropdown messages-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <i class=\"fa fa-envelope-o\"></i>\n                  <span class=\"label label-success\">4</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <li class=\"header\">You have 4 messages</li>\n                  <li>\n                    <!-- inner menu: contains the actual data -->\n                    <ul class=\"menu\">\n                      <li><!-- start message -->\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\"/>\n                          </div>\n                          <h4>\n                            Support Team\n                            <small><i class=\"fa fa-clock-o\"></i> 5 mins</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li><!-- end message -->\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user3-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            AdminLTE Design Team\n                            <small><i class=\"fa fa-clock-o\"></i> 2 hours</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user4-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            Developers\n                            <small><i class=\"fa fa-clock-o\"></i> Today</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user3-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            Sales Department\n                            <small><i class=\"fa fa-clock-o\"></i> Yesterday</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user4-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            Reviewers\n                            <small><i class=\"fa fa-clock-o\"></i> 2 days</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                    </ul>\n                  </li>\n                  <li class=\"footer\"><a href=\"#\">See All Messages</a></li>\n                </ul>\n              </li>\n              <!-- Notifications: style can be found in dropdown.less -->\n              <li class=\"dropdown notifications-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <i class=\"fa fa-bell-o\"></i>\n                  <span class=\"label label-warning\">10</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <li class=\"header\">You have 10 notifications</li>\n                  <li>\n                    <!-- inner menu: contains the actual data -->\n                    <ul class=\"menu\">\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-users text-aqua\"></i> 5 new members joined today\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-warning text-yellow\"></i> Very long description here that may not fit into the page and may cause design problems\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-users text-red\"></i> 5 new members joined\n                        </a>\n                      </li>\n\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-shopping-cart text-green\"></i> 25 sales made\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-user text-red\"></i> You changed your username\n                        </a>\n                      </li>\n                    </ul>\n                  </li>\n                  <li class=\"footer\"><a href=\"#\">View all</a></li>\n                </ul>\n              </li>\n              <!-- Tasks: style can be found in dropdown.less -->\n              <li class=\"dropdown tasks-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <i class=\"fa fa-flag-o\"></i>\n                  <span class=\"label label-danger\">9</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <li class=\"header\">You have 9 tasks</li>\n                  <li>\n                    <!-- inner menu: contains the actual data -->\n                    <ul class=\"menu\">\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Design some buttons\n                            <small class=\"pull-right\">20%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-aqua\" style=\"width: 20%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">20% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Create a nice theme\n                            <small class=\"pull-right\">40%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-green\" style=\"width: 40%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">40% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Some task I need to do\n                            <small class=\"pull-right\">60%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-red\" style=\"width: 60%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">60% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Make beautiful transitions\n                            <small class=\"pull-right\">80%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-yellow\" style=\"width: 80%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">80% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                    </ul>\n                  </li>\n                  <li class=\"footer\">\n                    <a href=\"#\">View all tasks</a>\n                  </li>\n                </ul>\n              </li>\n              <!-- User Account: style can be found in dropdown.less -->\n              <li class=\"dropdown user user-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <img src=\"dist/img/user2-160x160.jpg\" class=\"user-image\" alt=\"User Image\"/>\n                  <span class=\"hidden-xs\">Alexander Pierce</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <!-- User image -->\n                  <li class=\"user-header\">\n                    <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\" />\n                    <p>\n                      Alexander Pierce - Web Developer\n                      <small>Member since Nov. 2012</small>\n                    </p>\n                  </li>\n                  <!-- Menu Body -->\n                  <li class=\"user-body\">\n                    <div class=\"col-xs-4 text-center\">\n                      <a href=\"#\">Followers</a>\n                    </div>\n                    <div class=\"col-xs-4 text-center\">\n                      <a href=\"#\">Sales</a>\n                    </div>\n                    <div class=\"col-xs-4 text-center\">\n                      <a href=\"#\">Friends</a>\n                    </div>\n                  </li>\n                  <!-- Menu Footer-->\n                  <li class=\"user-footer\">\n                    <div class=\"pull-left\">\n                      <a href=\"#\" class=\"btn btn-default btn-flat\">Profile</a>\n                    </div>\n                    <div class=\"pull-right\">\n                      <a href=\"#\" class=\"btn btn-default btn-flat\">Sign out</a>\n                    </div>\n                  </li>\n                </ul>\n              </li>\n            </ul>\n          </div>\n        </nav>\n      </header>\n      <!-- Left side column. contains the logo and sidebar -->\n      <aside class=\"main-sidebar\">\n        <!-- sidebar: style can be found in sidebar.less -->\n        <section class=\"sidebar\">\n          <!-- Sidebar user panel -->\n          <div class=\"user-panel\">\n            <div class=\"pull-left image\">\n              <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\" />\n            </div>\n            <div class=\"pull-left info\">\n              <p>Alexander Pierce</p>\n\n              <a href=\"#\"><i class=\"fa fa-circle text-success\"></i> Online</a>\n            </div>\n          </div>\n          <!-- search form -->\n          <form action=\"#\" method=\"get\" class=\"sidebar-form\">\n            <div class=\"input-group\">\n              <input type=\"text\" name=\"q\" class=\"form-control\" placeholder=\"Search...\"/>\n              <span class=\"input-group-btn\">\n                <button type='submit' name='search' id='search-btn' class=\"btn btn-flat\"><i class=\"fa fa-search\"></i></button>\n              </span>\n            </div>\n          </form>\n          <!-- /.search form -->\n          <!-- sidebar menu: : style can be found in sidebar.less -->\n          <ul class=\"sidebar-menu\">\n            <li class=\"header\">MAIN NAVIGATION</li>\n                       \n            <li>\n              <a routerLink=\"/jobtitle\">\n                <i class=\"fa fa-th\"></i> <span>Job Title</span> \n              </a>\n            </li>\n            <li>\n              <a routerLink=\"/department\">\n                <i class=\"fa fa-envelope\"></i> <span>Department</span>                \n              </a>\n            </li>        \n            \n            <li>\n              <a routerLink=\"/client\">\n                <i class=\"fa fa-calendar\"></i> <span>Client</span>\n              </a>\n            </li>\n            <li>\n              <a routerLink=\"/addclient\">\n                <i class=\"fa fa-calendar\"></i> <span>Add Client</span>\n              </a>\n            </li>\n           \n           \n           \n          </ul>\n        </section>\n        <!-- /.sidebar -->\n      </aside>\n\n      <!-- Right side column. Contains the navbar and content of the page -->\n      <div class=\"content-wrapper\">\n        <!-- Content Header (Page header) -->\n        <section class=\"content-header\">\n          <h1>\n            Dashboard\n            <small>Control panel</small>\n          </h1>\n          <ol class=\"breadcrumb\">\n            <li><a href=\"#\"><i class=\"fa fa-dashboard\"></i> Home</a></li>\n            <li class=\"active\">Dashboard</li>\n          </ol>\n        </section>\n\n        <!-- Main content -->\n        <section class=\"content\">\n          <!-- Small boxes (Stat box) -->\n                     \n          <div class=\"row\">\n            <div class=\"col-xs-12\">\n              <div class=\"box\">\n                <div class=\"box-header\">\n                  <h3 class=\"box-title\">Clients</h3>\n                  <div class=\"box-tools\">\n                    <div class=\"input-group\">\n                      <!--<input type=\"text\" name=\"table_search\" class=\"form-control input-sm pull-right\" style=\"width: 150px;\" placeholder=\"Search\">\n                      <div class=\"input-group-btn\">\n                        <button class=\"btn btn-sm btn-default\"><i class=\"fa fa-search\"></i></button>\n                      </div>-->\n                    </div>\n                  </div>\n                </div><!-- /.box-header -->\n                <div class=\"box-body table-responsive no-padding\">\n                  <table class=\"table table-hover\">\n                    <tbody>\n                      <tr>\n                      <th>Full name</th>\n                      <th>E-mail</th>\n                      <th>Birth date</th>\n                      <th>Job title</th>\n                      <th>Department</th>\n                      <th>Edit</th>\n                      <th>Delete</th>\n                    </tr>\n                    <tr *ngFor=\"let cl of clientData\">\n                      <td>{{cl.clientName}}</td>\n                      <td>{{cl.mail}}</td>\n                      <td>{{cl.birthdate}}</td>\n                      <td>{{cl.jobTitle}}</td>\n                      <td>{{cl.departmentName}}</td>\n                      <td><a routerLink=\"/editclient/{{cl.clientId}}\" class=\"btn btn-sm btn-default\">Edit</a></td>\n                      <td><button type=\"button\" class=\"btn btn-sm btn-default\" (click)=\"DeleteClient(cl.clientId)\">Delete</button></td>\n                    </tr>\n                   \n                  </tbody></table>\n                </div><!-- /.box-body -->\n              </div><!-- /.box -->\n            </div>\n          </div>      \n          \n        </section><!-- /.content -->\n      </div><!-- /.content-wrapper -->\n      <footer class=\"main-footer\">\n        <div class=\"pull-right hidden-xs\">\n          <b>Version</b> 2.0\n        </div>\n        <strong>Copyright &copy; 2014-2015 <a href=\"http://almsaeedstudio.com\">Almsaeed Studio</a>.</strong> All rights reserved.\n      </footer>\n    </div><!-- ./wrapper -->\n\n"

/***/ }),

/***/ "./src/app/client/client.component.scss":
/*!**********************************************!*\
  !*** ./src/app/client/client.component.scss ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NsaWVudC9jbGllbnQuY29tcG9uZW50LnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/client/client.component.ts":
/*!********************************************!*\
  !*** ./src/app/client/client.component.ts ***!
  \********************************************/
/*! exports provided: ClientComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientComponent", function() { return ClientComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _client_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../client-api.service */ "./src/app/client-api.service.ts");



var ClientComponent = /** @class */ (function () {
    function ClientComponent(api) {
        this.api = api;
        this.clientData = [];
    }
    ClientComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.api.getClient().subscribe(function (res) { return _this.clientData = res; });
    };
    ClientComponent.prototype.DeleteClient = function (id) {
        var _this = this;
        var conf = confirm("Are you want to delete this client!");
        if (conf == true) {
            this.api.deleteClient(id).subscribe(function (res) { return _this.clientData = res; });
        }
    };
    ClientComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-client',
            template: __webpack_require__(/*! ./client.component.html */ "./src/app/client/client.component.html"),
            styles: [__webpack_require__(/*! ./client.component.scss */ "./src/app/client/client.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_client_api_service__WEBPACK_IMPORTED_MODULE_2__["ClientApiService"]])
    ], ClientComponent);
    return ClientComponent;
}());



/***/ }),

/***/ "./src/app/clientclass.ts":
/*!********************************!*\
  !*** ./src/app/clientclass.ts ***!
  \********************************/
/*! exports provided: clients */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clients", function() { return clients; });
var clients = /** @class */ (function () {
    function clients() {
    }
    return clients;
}());



/***/ }),

/***/ "./src/app/departments/departments.component.html":
/*!********************************************************!*\
  !*** ./src/app/departments/departments.component.html ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n\r\n    <div class=\"wrapper\">\r\n      \r\n      <header class=\"main-header\">\r\n        <!-- Logo -->\r\n        <a href=\"index2.html\" class=\"logo\"><b>Admin</b>LTE</a>\r\n        <!-- Header Navbar: style can be found in header.less -->\r\n        <nav class=\"navbar navbar-static-top\" role=\"navigation\">\r\n          <!-- Sidebar toggle button-->\r\n          <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">\r\n            <span class=\"sr-only\">Toggle navigation</span>\r\n          </a>\r\n          <div class=\"navbar-custom-menu\">\r\n            <ul class=\"nav navbar-nav\">\r\n              <!-- Messages: style can be found in dropdown.less-->\r\n              <li class=\"dropdown messages-menu\">\r\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\r\n                  <i class=\"fa fa-envelope-o\"></i>\r\n                  <span class=\"label label-success\">4</span>\r\n                </a>\r\n                <ul class=\"dropdown-menu\">\r\n                  <li class=\"header\">You have 4 messages</li>\r\n                  <li>\r\n                    <!-- inner menu: contains the actual data -->\r\n                    <ul class=\"menu\">\r\n                      <li><!-- start message -->\r\n                        <a href=\"#\">\r\n                          <div class=\"pull-left\">\r\n                            <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\"/>\r\n                          </div>\r\n                          <h4>\r\n                            Support Team\r\n                            <small><i class=\"fa fa-clock-o\"></i> 5 mins</small>\r\n                          </h4>\r\n                          <p>Why not buy a new awesome theme?</p>\r\n                        </a>\r\n                      </li><!-- end message -->\r\n                      <li>\r\n                        <a href=\"#\">\r\n                          <div class=\"pull-left\">\r\n                            <img src=\"dist/img/user3-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\r\n                          </div>\r\n                          <h4>\r\n                            AdminLTE Design Team\r\n                            <small><i class=\"fa fa-clock-o\"></i> 2 hours</small>\r\n                          </h4>\r\n                          <p>Why not buy a new awesome theme?</p>\r\n                        </a>\r\n                      </li>\r\n                      <li>\r\n                        <a href=\"#\">\r\n                          <div class=\"pull-left\">\r\n                            <img src=\"dist/img/user4-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\r\n                          </div>\r\n                          <h4>\r\n                            Developers\r\n                            <small><i class=\"fa fa-clock-o\"></i> Today</small>\r\n                          </h4>\r\n                          <p>Why not buy a new awesome theme?</p>\r\n                        </a>\r\n                      </li>\r\n                      <li>\r\n                        <a href=\"#\">\r\n                          <div class=\"pull-left\">\r\n                            <img src=\"dist/img/user3-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\r\n                          </div>\r\n                          <h4>\r\n                            Sales Department\r\n                            <small><i class=\"fa fa-clock-o\"></i> Yesterday</small>\r\n                          </h4>\r\n                          <p>Why not buy a new awesome theme?</p>\r\n                        </a>\r\n                      </li>\r\n                      <li>\r\n                        <a href=\"#\">\r\n                          <div class=\"pull-left\">\r\n                            <img src=\"dist/img/user4-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\r\n                          </div>\r\n                          <h4>\r\n                            Reviewers\r\n                            <small><i class=\"fa fa-clock-o\"></i> 2 days</small>\r\n                          </h4>\r\n                          <p>Why not buy a new awesome theme?</p>\r\n                        </a>\r\n                      </li>\r\n                    </ul>\r\n                  </li>\r\n                  <li class=\"footer\"><a href=\"#\">See All Messages</a></li>\r\n                </ul>\r\n              </li>\r\n              <!-- Notifications: style can be found in dropdown.less -->\r\n              <li class=\"dropdown notifications-menu\">\r\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\r\n                  <i class=\"fa fa-bell-o\"></i>\r\n                  <span class=\"label label-warning\">10</span>\r\n                </a>\r\n                <ul class=\"dropdown-menu\">\r\n                  <li class=\"header\">You have 10 notifications</li>\r\n                  <li>\r\n                    <!-- inner menu: contains the actual data -->\r\n                    <ul class=\"menu\">\r\n                      <li>\r\n                        <a href=\"#\">\r\n                          <i class=\"fa fa-users text-aqua\"></i> 5 new members joined today\r\n                        </a>\r\n                      </li>\r\n                      <li>\r\n                        <a href=\"#\">\r\n                          <i class=\"fa fa-warning text-yellow\"></i> Very long description here that may not fit into the page and may cause design problems\r\n                        </a>\r\n                      </li>\r\n                      <li>\r\n                        <a href=\"#\">\r\n                          <i class=\"fa fa-users text-red\"></i> 5 new members joined\r\n                        </a>\r\n                      </li>\r\n\r\n                      <li>\r\n                        <a href=\"#\">\r\n                          <i class=\"fa fa-shopping-cart text-green\"></i> 25 sales made\r\n                        </a>\r\n                      </li>\r\n                      <li>\r\n                        <a href=\"#\">\r\n                          <i class=\"fa fa-user text-red\"></i> You changed your username\r\n                        </a>\r\n                      </li>\r\n                    </ul>\r\n                  </li>\r\n                  <li class=\"footer\"><a href=\"#\">View all</a></li>\r\n                </ul>\r\n              </li>\r\n              <!-- Tasks: style can be found in dropdown.less -->\r\n              <li class=\"dropdown tasks-menu\">\r\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\r\n                  <i class=\"fa fa-flag-o\"></i>\r\n                  <span class=\"label label-danger\">9</span>\r\n                </a>\r\n                <ul class=\"dropdown-menu\">\r\n                  <li class=\"header\">You have 9 tasks</li>\r\n                  <li>\r\n                    <!-- inner menu: contains the actual data -->\r\n                    <ul class=\"menu\">\r\n                      <li><!-- Task item -->\r\n                        <a href=\"#\">\r\n                          <h3>\r\n                            Design some buttons\r\n                            <small class=\"pull-right\">20%</small>\r\n                          </h3>\r\n                          <div class=\"progress xs\">\r\n                            <div class=\"progress-bar progress-bar-aqua\" style=\"width: 20%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\r\n                              <span class=\"sr-only\">20% Complete</span>\r\n                            </div>\r\n                          </div>\r\n                        </a>\r\n                      </li><!-- end task item -->\r\n                      <li><!-- Task item -->\r\n                        <a href=\"#\">\r\n                          <h3>\r\n                            Create a nice theme\r\n                            <small class=\"pull-right\">40%</small>\r\n                          </h3>\r\n                          <div class=\"progress xs\">\r\n                            <div class=\"progress-bar progress-bar-green\" style=\"width: 40%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\r\n                              <span class=\"sr-only\">40% Complete</span>\r\n                            </div>\r\n                          </div>\r\n                        </a>\r\n                      </li><!-- end task item -->\r\n                      <li><!-- Task item -->\r\n                        <a href=\"#\">\r\n                          <h3>\r\n                            Some task I need to do\r\n                            <small class=\"pull-right\">60%</small>\r\n                          </h3>\r\n                          <div class=\"progress xs\">\r\n                            <div class=\"progress-bar progress-bar-red\" style=\"width: 60%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\r\n                              <span class=\"sr-only\">60% Complete</span>\r\n                            </div>\r\n                          </div>\r\n                        </a>\r\n                      </li><!-- end task item -->\r\n                      <li><!-- Task item -->\r\n                        <a href=\"#\">\r\n                          <h3>\r\n                            Make beautiful transitions\r\n                            <small class=\"pull-right\">80%</small>\r\n                          </h3>\r\n                          <div class=\"progress xs\">\r\n                            <div class=\"progress-bar progress-bar-yellow\" style=\"width: 80%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\r\n                              <span class=\"sr-only\">80% Complete</span>\r\n                            </div>\r\n                          </div>\r\n                        </a>\r\n                      </li><!-- end task item -->\r\n                    </ul>\r\n                  </li>\r\n                  <li class=\"footer\">\r\n                    <a href=\"#\">View all tasks</a>\r\n                  </li>\r\n                </ul>\r\n              </li>\r\n              <!-- User Account: style can be found in dropdown.less -->\r\n              <li class=\"dropdown user user-menu\">\r\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\r\n                  <img src=\"dist/img/user2-160x160.jpg\" class=\"user-image\" alt=\"User Image\"/>\r\n                  <span class=\"hidden-xs\">Alexander Pierce</span>\r\n                </a>\r\n                <ul class=\"dropdown-menu\">\r\n                  <!-- User image -->\r\n                  <li class=\"user-header\">\r\n                    <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\" />\r\n                    <p>\r\n                      Alexander Pierce - Web Developer\r\n                      <small>Member since Nov. 2012</small>\r\n                    </p>\r\n                  </li>\r\n                  <!-- Menu Body -->\r\n                  <li class=\"user-body\">\r\n                    <div class=\"col-xs-4 text-center\">\r\n                      <a href=\"#\">Followers</a>\r\n                    </div>\r\n                    <div class=\"col-xs-4 text-center\">\r\n                      <a href=\"#\">Sales</a>\r\n                    </div>\r\n                    <div class=\"col-xs-4 text-center\">\r\n                      <a href=\"#\">Friends</a>\r\n                    </div>\r\n                  </li>\r\n                  <!-- Menu Footer-->\r\n                  <li class=\"user-footer\">\r\n                    <div class=\"pull-left\">\r\n                      <a href=\"#\" class=\"btn btn-default btn-flat\">Profile</a>\r\n                    </div>\r\n                    <div class=\"pull-right\">\r\n                      <a href=\"#\" class=\"btn btn-default btn-flat\">Sign out</a>\r\n                    </div>\r\n                  </li>\r\n                </ul>\r\n              </li>\r\n            </ul>\r\n          </div>\r\n        </nav>\r\n      </header>\r\n      <!-- Left side column. contains the logo and sidebar -->\r\n      <aside class=\"main-sidebar\">\r\n        <!-- sidebar: style can be found in sidebar.less -->\r\n        <section class=\"sidebar\">\r\n          <!-- Sidebar user panel -->\r\n          <div class=\"user-panel\">\r\n            <div class=\"pull-left image\">\r\n              <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\" />\r\n            </div>\r\n            <div class=\"pull-left info\">\r\n              <p>Alexander Pierce</p>\r\n\r\n              <a href=\"#\"><i class=\"fa fa-circle text-success\"></i> Online</a>\r\n            </div>\r\n          </div>\r\n          <!-- search form -->\r\n          <form action=\"#\" method=\"get\" class=\"sidebar-form\">\r\n            <div class=\"input-group\">\r\n              <input type=\"text\" name=\"q\" class=\"form-control\" placeholder=\"Search...\"/>\r\n              <span class=\"input-group-btn\">\r\n                <button type='submit' name='search' id='search-btn' class=\"btn btn-flat\"><i class=\"fa fa-search\"></i></button>\r\n              </span>\r\n            </div>\r\n          </form>\r\n          <!-- /.search form -->\r\n          <!-- sidebar menu: : style can be found in sidebar.less -->\r\n          <ul class=\"sidebar-menu\">\r\n            <li class=\"header\">MAIN NAVIGATION</li>\r\n                       \r\n            <li>\r\n              <a routerLink=\"/jobtitle\">\r\n                <i class=\"fa fa-th\"></i> <span>Job Title</span> \r\n              </a>\r\n            </li>\r\n            <li>\r\n              <a routerLink=\"/department\">\r\n                <i class=\"fa fa-envelope\"></i> <span>Department</span>                \r\n              </a>\r\n            </li>        \r\n            \r\n            <li>\r\n              <a routerLink=\"/client\">\r\n                <i class=\"fa fa-calendar\"></i> <span>Client</span>\r\n              </a>\r\n            </li>\r\n            <li>\r\n              <a routerLink=\"/addclient\">\r\n                <i class=\"fa fa-calendar\"></i> <span>Add Client</span>\r\n              </a>\r\n            </li>\r\n           \r\n           \r\n           \r\n          </ul>\r\n        </section>\r\n        <!-- /.sidebar -->\r\n      </aside>\r\n\r\n      <!-- Right side column. Contains the navbar and content of the page -->\r\n      <div class=\"content-wrapper\">\r\n        <!-- Content Header (Page header) -->\r\n        <section class=\"content-header\">\r\n          <h1>\r\n            Dashboard\r\n            <small>Control panel</small>\r\n          </h1>\r\n          <ol class=\"breadcrumb\">\r\n            <li><a href=\"#\"><i class=\"fa fa-dashboard\"></i> Home</a></li>\r\n            <li class=\"active\">Dashboard</li>\r\n          </ol>\r\n        </section>\r\n\r\n        <!-- Main content -->\r\n        <section class=\"content\">\r\n          <!-- Small boxes (Stat box) -->\r\n          <div class=\"row\">\r\n            <!-- left column -->\r\n            <div class=\"col-md-6\">\r\n              <!-- general form elements -->\r\n              <div class=\"box box-primary\">\r\n                <div class=\"box-header\">\r\n                  <h3 class=\"box-title\">Add Department</h3>\r\n                </div><!-- /.box-header -->\r\n                <!-- form start -->\r\n                <form role=\"form\">\r\n                  <div class=\"box-body\">\r\n                    <div class=\"form-group\">\r\n                      <label for=\"jobTitle\">Department name</label>\r\n                      <input #department type=\"text\" class=\"form-control\"  placeholder=\"Department name\">\r\n                    </div>\r\n                     \r\n                  </div><!-- /.box-body -->\r\n\r\n                  <div class=\"box-footer\">\r\n                    <button type=\"button\" class=\"btn btn-primary\" (click)=\"AddDepartment(department.value)\">Submit</button>\r\n                  </div>\r\n                </form>\r\n              </div><!-- /.box -->\r\n           \r\n              <!-- Input addon -->\r\n              \r\n\r\n            </div><!--/.col (left) -->\r\n            <!-- right column -->\r\n            \r\n          </div>\r\n           \r\n          <div class=\"row\">\r\n            <div class=\"col-xs-12\">\r\n              <div class=\"box\">\r\n                <div class=\"box-header\">\r\n                  <h3 class=\"box-title\">Jobs</h3>\r\n                  <div class=\"box-tools\">\r\n                    <div class=\"input-group\">\r\n                      <!--<input type=\"text\" name=\"table_search\" class=\"form-control input-sm pull-right\" style=\"width: 150px;\" placeholder=\"Search\">\r\n                      <div class=\"input-group-btn\">\r\n                        <button class=\"btn btn-sm btn-default\"><i class=\"fa fa-search\"></i></button>\r\n                      </div>-->\r\n                    </div>\r\n                  </div>\r\n                </div><!-- /.box-header -->\r\n                <div class=\"box-body table-responsive no-padding\">\r\n                  <table class=\"table table-hover\">\r\n                    <tbody>\r\n                    <tr>\r\n                      <th>Job title</th>\r\n                      <th>Edit</th>\r\n                      <th>Delete</th>\r\n                    </tr>\r\n                     <tr *ngFor=\"let depart of data\">\r\n                       <td>{{depart.departmentName}}</td>\r\n                      <td><button type=\"button\" class=\"btn btn-sm btn-default\" data-toggle=\"modal\" data-target=\"#myModal\" (click)=\"departNameedit.value=depart.departmentName;departId.value=depart.depaId\">Edit</button></td>\r\n                      <td><button type=\"button\" class=\"btn btn-sm btn-default\" (click)=\"DeleteDepartment(depart.depaId)\">Delete</button></td>\r\n                    </tr>\r\n                   \r\n                  </tbody></table>\r\n                </div><!-- /.box-body -->\r\n              </div><!-- /.box -->\r\n            </div>\r\n          </div>      \r\n          \r\n        </section><!-- /.content -->\r\n      </div><!-- /.content-wrapper -->\r\n      <footer class=\"main-footer\">\r\n        <div class=\"pull-right hidden-xs\">\r\n          <b>Version</b> 2.0\r\n        </div>\r\n        <strong>Copyright &copy; 2014-2015 <a href=\"http://almsaeedstudio.com\">Almsaeed Studio</a>.</strong> All rights reserved.\r\n      </footer>\r\n    </div><!-- ./wrapper -->\r\n\r\n \r\n\r\n  <!-- Modal -->\r\n  <div class=\"modal fade\" id=\"myModal\" role=\"dialog\">\r\n    <div class=\"modal-dialog\">\r\n    \r\n      <!-- Modal content-->\r\n      <div class=\"modal-content\">\r\n        <div class=\"modal-header\">\r\n          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\r\n          <h4 class=\"modal-title\">Edit</h4>\r\n        </div>\r\n        <div class=\"modal-body\">\r\n          <div class=\"box-body\">\r\n            <div class=\"form-group\">\r\n               <label for=\"jobTitle\">Job title</label>\r\n               <input #departNameedit type=\"text\" class=\"form-control\"  placeholder=\"\">\r\n               <input #departId type=\"text\" hidden>\r\n            </div>\r\n                     \r\n          </div><!-- /.box-body -->\r\n        </div>\r\n        <div class=\"modal-footer\">\r\n          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" (click)=\"EditDepartment(departId.value,departNameedit.value)\">Done</button>\r\n        </div>\r\n      </div>\r\n      \r\n    </div>\r\n  </div>\r\n  \r\n    \r\n\r\n"

/***/ }),

/***/ "./src/app/departments/departments.component.scss":
/*!********************************************************!*\
  !*** ./src/app/departments/departments.component.scss ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2RlcGFydG1lbnRzL2RlcGFydG1lbnRzLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/departments/departments.component.ts":
/*!******************************************************!*\
  !*** ./src/app/departments/departments.component.ts ***!
  \******************************************************/
/*! exports provided: DepartmentsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DepartmentsComponent", function() { return DepartmentsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");



var DepartmentsComponent = /** @class */ (function () {
    function DepartmentsComponent(api) {
        this.api = api;
        this.displayedColumns = ['departid', 'departname'];
        this.departname = '';
        this.isLoadingResults = true;
    }
    DepartmentsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.api.getDepartment()
            .subscribe(function (res) {
            _this.data = res;
            console.log(_this.data);
            _this.isLoadingResults = false;
        }, function (err) {
            console.log(err);
            _this.isLoadingResults = false;
        });
    };
    DepartmentsComponent.prototype.AddDepartment = function (depart) {
        //this.senddata.departmentName='new depart';
        var _this = this;
        var newdepart = { departmentName: depart, depaId: 0 };
        this.api.addDepart(newdepart).subscribe(function (res) { return _this.data = res; });
    };
    DepartmentsComponent.prototype.DeleteDepartment = function (id) {
        var _this = this;
        var conf = confirm("Are you want to delete this department!");
        if (conf == true) {
            this.api.deleteDepart(id).subscribe(function (res) { return _this.data = res; });
        }
    };
    DepartmentsComponent.prototype.EditDepartment = function (id, depart) {
        var _this = this;
        var department = { departmentName: depart, depaId: id };
        this.api.EditDepart(department).subscribe(function (res) { return _this.data = res; });
    };
    DepartmentsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-departments',
            template: __webpack_require__(/*! ./departments.component.html */ "./src/app/departments/departments.component.html"),
            styles: [__webpack_require__(/*! ./departments.component.scss */ "./src/app/departments/departments.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]])
    ], DepartmentsComponent);
    return DepartmentsComponent;
}());



/***/ }),

/***/ "./src/app/editclient/editclient.component.html":
/*!******************************************************!*\
  !*** ./src/app/editclient/editclient.component.html ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = " <div class=\"wrapper\">\n      \n      <header class=\"main-header\">\n        <!-- Logo -->\n        <a href=\"index2.html\" class=\"logo\"><b>Admin</b>LTE</a>\n        <!-- Header Navbar: style can be found in header.less -->\n        <nav class=\"navbar navbar-static-top\" role=\"navigation\">\n          <!-- Sidebar toggle button-->\n          <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">\n            <span class=\"sr-only\">Toggle navigation</span>\n          </a>\n          <div class=\"navbar-custom-menu\">\n            <ul class=\"nav navbar-nav\">\n              <!-- Messages: style can be found in dropdown.less-->\n              <li class=\"dropdown messages-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <i class=\"fa fa-envelope-o\"></i>\n                  <span class=\"label label-success\">4</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <li class=\"header\">You have 4 messages</li>\n                  <li>\n                    <!-- inner menu: contains the actual data -->\n                    <ul class=\"menu\">\n                      <li><!-- start message -->\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\"/>\n                          </div>\n                          <h4>\n                            Support Team\n                            <small><i class=\"fa fa-clock-o\"></i> 5 mins</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li><!-- end message -->\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user3-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            AdminLTE Design Team\n                            <small><i class=\"fa fa-clock-o\"></i> 2 hours</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user4-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            Developers\n                            <small><i class=\"fa fa-clock-o\"></i> Today</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user3-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            Sales Department\n                            <small><i class=\"fa fa-clock-o\"></i> Yesterday</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user4-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            Reviewers\n                            <small><i class=\"fa fa-clock-o\"></i> 2 days</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                    </ul>\n                  </li>\n                  <li class=\"footer\"><a href=\"#\">See All Messages</a></li>\n                </ul>\n              </li>\n              <!-- Notifications: style can be found in dropdown.less -->\n              <li class=\"dropdown notifications-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <i class=\"fa fa-bell-o\"></i>\n                  <span class=\"label label-warning\">10</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <li class=\"header\">You have 10 notifications</li>\n                  <li>\n                    <!-- inner menu: contains the actual data -->\n                    <ul class=\"menu\">\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-users text-aqua\"></i> 5 new members joined today\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-warning text-yellow\"></i> Very long description here that may not fit into the page and may cause design problems\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-users text-red\"></i> 5 new members joined\n                        </a>\n                      </li>\n\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-shopping-cart text-green\"></i> 25 sales made\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-user text-red\"></i> You changed your username\n                        </a>\n                      </li>\n                    </ul>\n                  </li>\n                  <li class=\"footer\"><a href=\"#\">View all</a></li>\n                </ul>\n              </li>\n              <!-- Tasks: style can be found in dropdown.less -->\n              <li class=\"dropdown tasks-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <i class=\"fa fa-flag-o\"></i>\n                  <span class=\"label label-danger\">9</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <li class=\"header\">You have 9 tasks</li>\n                  <li>\n                    <!-- inner menu: contains the actual data -->\n                    <ul class=\"menu\">\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Design some buttons\n                            <small class=\"pull-right\">20%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-aqua\" style=\"width: 20%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">20% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Create a nice theme\n                            <small class=\"pull-right\">40%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-green\" style=\"width: 40%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">40% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Some task I need to do\n                            <small class=\"pull-right\">60%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-red\" style=\"width: 60%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">60% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Make beautiful transitions\n                            <small class=\"pull-right\">80%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-yellow\" style=\"width: 80%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">80% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                    </ul>\n                  </li>\n                  <li class=\"footer\">\n                    <a href=\"#\">View all tasks</a>\n                  </li>\n                </ul>\n              </li>\n              <!-- User Account: style can be found in dropdown.less -->\n              <li class=\"dropdown user user-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <img src=\"dist/img/user2-160x160.jpg\" class=\"user-image\" alt=\"User Image\"/>\n                  <span class=\"hidden-xs\">Alexander Pierce</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <!-- User image -->\n                  <li class=\"user-header\">\n                    <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\" />\n                    <p>\n                      Alexander Pierce - Web Developer\n                      <small>Member since Nov. 2012</small>\n                    </p>\n                  </li>\n                  <!-- Menu Body -->\n                  <li class=\"user-body\">\n                    <div class=\"col-xs-4 text-center\">\n                      <a href=\"#\">Followers</a>\n                    </div>\n                    <div class=\"col-xs-4 text-center\">\n                      <a href=\"#\">Sales</a>\n                    </div>\n                    <div class=\"col-xs-4 text-center\">\n                      <a href=\"#\">Friends</a>\n                    </div>\n                  </li>\n                  <!-- Menu Footer-->\n                  <li class=\"user-footer\">\n                    <div class=\"pull-left\">\n                      <a href=\"#\" class=\"btn btn-default btn-flat\">Profile</a>\n                    </div>\n                    <div class=\"pull-right\">\n                      <a href=\"#\" class=\"btn btn-default btn-flat\">Sign out</a>\n                    </div>\n                  </li>\n                </ul>\n              </li>\n            </ul>\n          </div>\n        </nav>\n      </header>\n      <!-- Left side column. contains the logo and sidebar -->\n      <aside class=\"main-sidebar\">\n        <!-- sidebar: style can be found in sidebar.less -->\n        <section class=\"sidebar\">\n          <!-- Sidebar user panel -->\n          <div class=\"user-panel\">\n            <div class=\"pull-left image\">\n              <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\" />\n            </div>\n            <div class=\"pull-left info\">\n              <p>Alexander Pierce</p>\n\n              <a href=\"#\"><i class=\"fa fa-circle text-success\"></i> Online</a>\n            </div>\n          </div>\n          <!-- search form -->\n          <form action=\"#\" method=\"get\" class=\"sidebar-form\">\n            <div class=\"input-group\">\n              <input type=\"text\" name=\"q\" class=\"form-control\" placeholder=\"Search...\"/>\n              <span class=\"input-group-btn\">\n                <button type='submit' name='search' id='search-btn' class=\"btn btn-flat\"><i class=\"fa fa-search\"></i></button>\n              </span>\n            </div>\n          </form>\n          <!-- /.search form -->\n          <!-- sidebar menu: : style can be found in sidebar.less -->\n          <ul class=\"sidebar-menu\">\n            <li class=\"header\">MAIN NAVIGATION</li>\n                       \n            <li>\n              <a routerLink=\"/jobtitle\">\n                <i class=\"fa fa-th\"></i> <span>Job Title</span> \n              </a>\n            </li>\n            <li>\n              <a routerLink=\"/department\">\n                <i class=\"fa fa-envelope\"></i> <span>Department</span>                \n              </a>\n            </li>        \n            \n            <li>\n              <a routerLink=\"/client\">\n                <i class=\"fa fa-calendar\"></i> <span>Client</span>\n              </a>\n            </li>\n            <li>\n              <a routerLink=\"/addclient\">\n                <i class=\"fa fa-calendar\"></i> <span>Add Client</span>\n              </a>\n            </li>\n           \n           \n           \n          </ul>\n        </section>\n        <!-- /.sidebar -->\n      </aside>\n\n      <!-- Right side column. Contains the navbar and content of the page -->\n      <div class=\"content-wrapper\">\n        <!-- Content Header (Page header) -->\n        <section class=\"content-header\">\n          <h1>\n            Dashboard\n            <small>Control panel</small>\n          </h1>\n          <ol class=\"breadcrumb\">\n            <li><a href=\"#\"><i class=\"fa fa-dashboard\"></i> Home</a></li>\n            <li class=\"active\">Dashboard</li>\n          </ol>\n        </section>\n\n        <!-- Main content -->\n        <section class=\"content\">\n          <!-- Small boxes (Stat box) -->\n          <div class=\"row\">\n             <form role=\"form\">\n            <!-- left column -->\n              <div class=\"col-md-6\">\n                <!-- general form elements -->\n                <div class=\"box box-primary\">\n                  <div class=\"box-header\">\n                    <h3 class=\"box-title\">Edit client</h3>\n                  </div><!-- /.box-header -->\n                  <!-- form start -->\n                \n                    <div class=\"box-body\">\n                      <div class=\"form-group\">\n                        <label for=\"nametxt\">Full name</label>\n                        <input #nametxt type=\"text\" class=\"form-control\" value=\"{{data.clientName}}\"  placeholder=\"Full name\">\n                      </div>\n                      <div class=\"form-group\">\n                        <label for=\"birthdate\">Birth date</label>\n                        <input #birthdate type=\"date\" class=\"form-control\" value=\"{{data.birthdate}}\"  placeholder=\"Birth date\">\n                      </div>\n                      <div class=\"form-group\">\n                        <label for=\"mailtxt\">E-mail Address</label>\n                        <input #mailtxt type=\"text\" class=\"form-control\" value=\"{{data.mail}}\"  placeholder=\"E-mail Address\">\n                      </div>\n                      <div class=\"form-group\">\n                      <label>Department</label>\n                      <select #depart class=\"form-control\" >\n                               <option *ngFor=\"let d of departdata\" value=\"{{d.depaId}}\">{{d.departmentName}}</option>               \n                      </select>\n                      </div>\n                      <div class=\"form-group\">\n                            <label>Job title</label>\n                            <select #job class=\"form-control\" >\n                                 <option *ngFor=\"let j of jobdata\" value=\"{{j.jobId}}\">{{j.jobTitle}}</option>                  \n                            </select>\n                      </div>\n                      <div class=\"form-group\">\n                        <label for=\"passtxt\">Password</label>\n                        <input #passtxt type=\"password\" class=\"form-control\"  placeholder=\"Password\">\n                      </div>\n                      <div class=\"form-group\">\n                        <label for=\"confirmpasstxt\">Confirm password</label>\n                        <input #confirmpasstxt type=\"password\" class=\"form-control\"  placeholder=\"Confirm password\">\n                      </div>\n                      <div class=\"form-group\">\n                        <label for=\"exampleInputFile\">Image</label>\n                        <input #img type=\"file\" id=\"exampleInputFile\" (change)=\"handleFileInput($event.target.files)\">\n                        <p class=\"help-block\"></p>\n                      </div>\n                    </div><!-- /.box-body -->\n  \n                    <div class=\"box-footer\">\n                      <button type=\"button\" class=\"btn btn-primary\" (click)=\"AddClient(nametxt.value,birthdate.value,mailtxt.value,\n                              depart.value,job.value,passtxt.value,confirmpasstxt.value,img.value)\">Submit</button>\n                    </div>\n                \n                </div><!-- /.box -->\n            \n                <!-- Input addon -->\n                  \n              </div><!--/.col (left) -->\n              \n              <div class=\"col-md-6\">\n                <div class=\"nav-tabs-custom\">\n                <ul class=\"nav nav-tabs\">\n                  <li class=\"active\"><a href=\"#tab_1\" data-toggle=\"tab\">Phone</a></li>\n                  <li><a href=\"#tab_2\" data-toggle=\"tab\">Address</a></li>\n                                    \n                </ul>\n                <div class=\"tab-content\">\n                  <div class=\"tab-pane active\" id=\"tab_1\">\n                    <div class=\"input-group input-group-sm\">\n                      <input #phone type=\"text\" class=\"form-control\">\n                      <span class=\"input-group-btn\">\n                      <button class=\"btn btn-info btn-flat\" type=\"button\" (click)=\"AddPhone(phone.value);phone.value=''\">Add</button>\n                      </span>\n                     </div>\n                    <div class=\"box\">\n                      <div class=\"box-header\">\n                        <h3 class=\"box-title\"></h3>\n                      </div><!-- /.box-header -->\n                      <div class=\"box-body no-padding\">\n                        <table class=\"table table-condensed\">\n                          <tbody>\n                          <tr >\n                            <th>Phone</th>\n                            <th>Delete</th>                      \n                          </tr>\n                          <tr *ngFor=\"let ph of phonenum ; let i = index\">\n                            <td>{{ph.phones}}</td>\n                            <td><button type=\"button\" (click)=\"DelPhone(i)\">X</button></td>                      \n                          </tr>\n                        </tbody></table>\n                      </div><!-- /.box-body -->\n                    </div>\n                  </div><!-- /.tab-pane -->\n                  <div class=\"tab-pane\" id=\"tab_2\">\n                    <div class=\"input-group input-group-sm\">\n                      <input #addresstxt type=\"text\" class=\"form-control\">\n                      <span class=\"input-group-btn\">\n                      <button class=\"btn btn-info btn-flat\" type=\"button\" (click)=\"AddAddress(addresstxt.value);addresstxt.value=''\">Add</button>\n                      </span>\n                     </div>\n                    <div class=\"box\">\n                      <div class=\"box-header\">\n                        <h3 class=\"box-title\"></h3>\n                      </div><!-- /.box-header -->\n                      <div class=\"box-body no-padding\">\n                        <table class=\"table table-condensed\">\n                          <tbody><tr>\n                            <th >Address</th>\n                            <th>Delete</th>                      \n                          </tr>\n                          <tr *ngFor=\"let ad of adders ; let i = index\">\n                            <td>{{ad.addres}}</td>\n                            <td><button type=\"button\" (click)=\"DelAddress(i)\">X</button></td>                      \n                          </tr>\n                        </tbody></table>\n                      </div><!-- /.box-body -->\n                    </div>\n                  </div><!-- /.tab-pane -->\n                </div><!-- /.tab-content -->\n              </div>\n              </div>\n            <!-- right column -->\n             </form>  \n          </div>\n         \n           \n          \n        </section><!-- /.content -->\n      </div><!-- /.content-wrapper -->\n      <footer class=\"main-footer\">\n        <div class=\"pull-right hidden-xs\">\n          <b>Version</b> 2.0\n        </div>\n        <strong>Copyright &copy; 2014-2015 <a href=\"http://almsaeedstudio.com\">Almsaeed Studio</a>.</strong> All rights reserved.\n      </footer>\n    </div><!-- ./wrapper -->\n"

/***/ }),

/***/ "./src/app/editclient/editclient.component.scss":
/*!******************************************************!*\
  !*** ./src/app/editclient/editclient.component.scss ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2VkaXRjbGllbnQvZWRpdGNsaWVudC5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/editclient/editclient.component.ts":
/*!****************************************************!*\
  !*** ./src/app/editclient/editclient.component.ts ***!
  \****************************************************/
/*! exports provided: EditclientComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditclientComponent", function() { return EditclientComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _client_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../client-api.service */ "./src/app/client-api.service.ts");
/* harmony import */ var _clientclass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../clientclass */ "./src/app/clientclass.ts");
/* harmony import */ var _job_api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../job-api.service */ "./src/app/job-api.service.ts");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");







var EditclientComponent = /** @class */ (function () {
    function EditclientComponent(route, api, jobapi, departapi) {
        this.route = route;
        this.api = api;
        this.jobapi = jobapi;
        this.departapi = departapi;
        this.phonenum = [];
        this.adders = [];
        this.jobdata = [];
        this.fileToUpload = null;
    }
    EditclientComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.departapi.getDepartment().subscribe(function (res) { _this.departdata = res; }, function (err) { console.log(err); });
        this.jobapi.getjobs().subscribe(function (res) { _this.jobdata = res; });
        var adata;
        var id = +this.route.snapshot.paramMap.get('id');
        console.log(id);
        this.api.getClientData(id).subscribe(function (res) { return _this.data = res; });
        this.api.getClientData(id).subscribe(function (res) { return _this.adders = res.clientAddress; });
        this.api.getClientData(id).subscribe(function (res) { return _this.phonenum = res.clientPhone; });
        //for(var i=0;i<this.addrs.length;i++){
        //  this.adders.push(this.addrs[i].addres);
        //}
        //for(var i=0;i<this.phos.length;i++){
        //  this.phonenum.push(this.phos[i].phones);
        //}
    };
    EditclientComponent.prototype.handleFileInput = function (files) {
        this.fileToUpload = files.item(0);
    };
    EditclientComponent.prototype.AddClient = function (name, birthdate, mail, department, job, pass, conf, img) {
        var id = +this.route.snapshot.paramMap.get('id');
        var formData = new FormData();
        formData.append('id', id.toString());
        formData.append('name', name);
        formData.append('birth', birthdate);
        formData.append('mail', mail);
        formData.append('department', department);
        formData.append('job', job);
        formData.append('pass', pass);
        formData.append('phones', JSON.stringify(this.phonenum));
        formData.append('addresses', JSON.stringify(this.adders));
        formData.append('file', this.fileToUpload);
        console.log(this.fileToUpload);
        this.api.editClient(formData).subscribe();
    };
    EditclientComponent.prototype.AddPhone = function (phone) {
        if (phone > 0)
            this.phonenum.push({ 'phones': phone, 'clientId': 0 });
    };
    EditclientComponent.prototype.DelPhone = function (index) {
        this.phonenum.pop();
    };
    EditclientComponent.prototype.AddAddress = function (address) {
        this.adders.push({ 'addres': address, 'clientId': 0 });
    };
    EditclientComponent.prototype.DelAddress = function (index) {
        this.adders.pop();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _clientclass__WEBPACK_IMPORTED_MODULE_4__["clients"])
    ], EditclientComponent.prototype, "data", void 0);
    EditclientComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-editclient',
            template: __webpack_require__(/*! ./editclient.component.html */ "./src/app/editclient/editclient.component.html"),
            styles: [__webpack_require__(/*! ./editclient.component.scss */ "./src/app/editclient/editclient.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _client_api_service__WEBPACK_IMPORTED_MODULE_3__["ClientApiService"], _job_api_service__WEBPACK_IMPORTED_MODULE_5__["JobApiService"], _api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]])
    ], EditclientComponent);
    return EditclientComponent;
}());



/***/ }),

/***/ "./src/app/job-api.service.ts":
/*!************************************!*\
  !*** ./src/app/job-api.service.ts ***!
  \************************************/
/*! exports provided: JobApiService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JobApiService", function() { return JobApiService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");





var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var apiUrl = '../api/JobTitle';
//const apiUrl = 'http://localhost:51195/api/JobTitle';
var JobApiService = /** @class */ (function () {
    function JobApiService(http) {
        this.http = http;
    }
    JobApiService.prototype.getjobs = function () {
        return this.http.get(apiUrl)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (heroes) { return console.log('fetched jobtitle'); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError('getjobs', [])));
    };
    JobApiService.prototype.addJob = function (job) {
        return this.http.post(apiUrl, job, httpOptions);
    };
    JobApiService.prototype.deleteJob = function (id) {
        var url = apiUrl + "/" + id;
        //this.http.delete(url, httpOptions).subscribe(response => console.log(response));
        return this.http.delete(url, httpOptions);
    };
    JobApiService.prototype.EditJob = function (job) {
        return this.http.put(apiUrl, job, httpOptions);
    };
    JobApiService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // Let the app keep running by returning an empty result.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(result);
        };
    };
    JobApiService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]])
    ], JobApiService);
    return JobApiService;
}());



/***/ }),

/***/ "./src/app/job-title/job-title.component.html":
/*!****************************************************!*\
  !*** ./src/app/job-title/job-title.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n    <div class=\"wrapper\">\n      \n      <header class=\"main-header\">\n        <!-- Logo -->\n        <a href=\"index2.html\" class=\"logo\"><b>Admin</b>LTE</a>\n        <!-- Header Navbar: style can be found in header.less -->\n        <nav class=\"navbar navbar-static-top\" role=\"navigation\">\n          <!-- Sidebar toggle button-->\n          <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">\n            <span class=\"sr-only\">Toggle navigation</span>\n          </a>\n          <div class=\"navbar-custom-menu\">\n            <ul class=\"nav navbar-nav\">\n              <!-- Messages: style can be found in dropdown.less-->\n              <li class=\"dropdown messages-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <i class=\"fa fa-envelope-o\"></i>\n                  <span class=\"label label-success\">4</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <li class=\"header\">You have 4 messages</li>\n                  <li>\n                    <!-- inner menu: contains the actual data -->\n                    <ul class=\"menu\">\n                      <li><!-- start message -->\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\"/>\n                          </div>\n                          <h4>\n                            Support Team\n                            <small><i class=\"fa fa-clock-o\"></i> 5 mins</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li><!-- end message -->\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user3-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            AdminLTE Design Team\n                            <small><i class=\"fa fa-clock-o\"></i> 2 hours</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user4-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            Developers\n                            <small><i class=\"fa fa-clock-o\"></i> Today</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user3-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            Sales Department\n                            <small><i class=\"fa fa-clock-o\"></i> Yesterday</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <div class=\"pull-left\">\n                            <img src=\"dist/img/user4-128x128.jpg\" class=\"img-circle\" alt=\"user image\"/>\n                          </div>\n                          <h4>\n                            Reviewers\n                            <small><i class=\"fa fa-clock-o\"></i> 2 days</small>\n                          </h4>\n                          <p>Why not buy a new awesome theme?</p>\n                        </a>\n                      </li>\n                    </ul>\n                  </li>\n                  <li class=\"footer\"><a href=\"#\">See All Messages</a></li>\n                </ul>\n              </li>\n              <!-- Notifications: style can be found in dropdown.less -->\n              <li class=\"dropdown notifications-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <i class=\"fa fa-bell-o\"></i>\n                  <span class=\"label label-warning\">10</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <li class=\"header\">You have 10 notifications</li>\n                  <li>\n                    <!-- inner menu: contains the actual data -->\n                    <ul class=\"menu\">\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-users text-aqua\"></i> 5 new members joined today\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-warning text-yellow\"></i> Very long description here that may not fit into the page and may cause design problems\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-users text-red\"></i> 5 new members joined\n                        </a>\n                      </li>\n\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-shopping-cart text-green\"></i> 25 sales made\n                        </a>\n                      </li>\n                      <li>\n                        <a href=\"#\">\n                          <i class=\"fa fa-user text-red\"></i> You changed your username\n                        </a>\n                      </li>\n                    </ul>\n                  </li>\n                  <li class=\"footer\"><a href=\"#\">View all</a></li>\n                </ul>\n              </li>\n              <!-- Tasks: style can be found in dropdown.less -->\n              <li class=\"dropdown tasks-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <i class=\"fa fa-flag-o\"></i>\n                  <span class=\"label label-danger\">9</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <li class=\"header\">You have 9 tasks</li>\n                  <li>\n                    <!-- inner menu: contains the actual data -->\n                    <ul class=\"menu\">\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Design some buttons\n                            <small class=\"pull-right\">20%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-aqua\" style=\"width: 20%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">20% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Create a nice theme\n                            <small class=\"pull-right\">40%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-green\" style=\"width: 40%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">40% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Some task I need to do\n                            <small class=\"pull-right\">60%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-red\" style=\"width: 60%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">60% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                      <li><!-- Task item -->\n                        <a href=\"#\">\n                          <h3>\n                            Make beautiful transitions\n                            <small class=\"pull-right\">80%</small>\n                          </h3>\n                          <div class=\"progress xs\">\n                            <div class=\"progress-bar progress-bar-yellow\" style=\"width: 80%\" role=\"progressbar\" aria-valuenow=\"20\" aria-valuemin=\"0\" aria-valuemax=\"100\">\n                              <span class=\"sr-only\">80% Complete</span>\n                            </div>\n                          </div>\n                        </a>\n                      </li><!-- end task item -->\n                    </ul>\n                  </li>\n                  <li class=\"footer\">\n                    <a href=\"#\">View all tasks</a>\n                  </li>\n                </ul>\n              </li>\n              <!-- User Account: style can be found in dropdown.less -->\n              <li class=\"dropdown user user-menu\">\n                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\n                  <img src=\"dist/img/user2-160x160.jpg\" class=\"user-image\" alt=\"User Image\"/>\n                  <span class=\"hidden-xs\">Alexander Pierce</span>\n                </a>\n                <ul class=\"dropdown-menu\">\n                  <!-- User image -->\n                  <li class=\"user-header\">\n                    <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\" />\n                    <p>\n                      Alexander Pierce - Web Developer\n                      <small>Member since Nov. 2012</small>\n                    </p>\n                  </li>\n                  <!-- Menu Body -->\n                  <li class=\"user-body\">\n                    <div class=\"col-xs-4 text-center\">\n                      <a href=\"#\">Followers</a>\n                    </div>\n                    <div class=\"col-xs-4 text-center\">\n                      <a href=\"#\">Sales</a>\n                    </div>\n                    <div class=\"col-xs-4 text-center\">\n                      <a href=\"#\">Friends</a>\n                    </div>\n                  </li>\n                  <!-- Menu Footer-->\n                  <li class=\"user-footer\">\n                    <div class=\"pull-left\">\n                      <a href=\"#\" class=\"btn btn-default btn-flat\">Profile</a>\n                    </div>\n                    <div class=\"pull-right\">\n                      <a href=\"#\" class=\"btn btn-default btn-flat\">Sign out</a>\n                    </div>\n                  </li>\n                </ul>\n              </li>\n            </ul>\n          </div>\n        </nav>\n      </header>\n      <!-- Left side column. contains the logo and sidebar -->\n      <aside class=\"main-sidebar\">\n        <!-- sidebar: style can be found in sidebar.less -->\n        <section class=\"sidebar\">\n          <!-- Sidebar user panel -->\n          <div class=\"user-panel\">\n            <div class=\"pull-left image\">\n              <img src=\"dist/img/user2-160x160.jpg\" class=\"img-circle\" alt=\"User Image\" />\n            </div>\n            <div class=\"pull-left info\">\n              <p>Alexander Pierce</p>\n\n              <a href=\"#\"><i class=\"fa fa-circle text-success\"></i> Online</a>\n            </div>\n          </div>\n          <!-- search form -->\n          <form action=\"#\" method=\"get\" class=\"sidebar-form\">\n            <div class=\"input-group\">\n              <input type=\"text\" name=\"q\" class=\"form-control\" placeholder=\"Search...\"/>\n              <span class=\"input-group-btn\">\n                <button type='submit' name='search' id='search-btn' class=\"btn btn-flat\"><i class=\"fa fa-search\"></i></button>\n              </span>\n            </div>\n          </form>\n          <!-- /.search form -->\n          <!-- sidebar menu: : style can be found in sidebar.less -->\n          <ul class=\"sidebar-menu\">\n            <li class=\"header\">MAIN NAVIGATION</li>\n                       \n            <li>\n              <a routerLink=\"/jobtitle\">\n                <i class=\"fa fa-th\"></i> <span>Job Title</span> \n              </a>\n            </li>\n            <li>\n              <a routerLink=\"/department\">\n                <i class=\"fa fa-envelope\"></i> <span>Department</span>                \n              </a>\n            </li>        \n            \n            <li>\n              <a routerLink=\"/client\">\n                <i class=\"fa fa-calendar\"></i> <span>Client</span>\n              </a>\n            </li>\n            <li>\n              <a routerLink=\"/addclient\">\n                <i class=\"fa fa-calendar\"></i> <span>Add Client</span>\n              </a>\n            </li>\n           \n           \n           \n          </ul>\n        </section>\n        <!-- /.sidebar -->\n      </aside>\n\n      <!-- Right side column. Contains the navbar and content of the page -->\n      <div class=\"content-wrapper\">\n        <!-- Content Header (Page header) -->\n        <section class=\"content-header\">\n          <h1>\n            Dashboard\n            <small>Control panel</small>\n          </h1>\n          <ol class=\"breadcrumb\">\n            <li><a href=\"#\"><i class=\"fa fa-dashboard\"></i> Home</a></li>\n            <li class=\"active\">Dashboard</li>\n          </ol>\n        </section>\n\n        <!-- Main content -->\n        <section class=\"content\">\n          <!-- Small boxes (Stat box) -->\n          <div class=\"row\">\n            <!-- left column -->\n            <div class=\"col-md-6\">\n              <!-- general form elements -->\n              <div class=\"box box-primary\">\n                <div class=\"box-header\">\n                  <h3 class=\"box-title\">Add Job title</h3>\n                </div><!-- /.box-header -->\n                <!-- form start -->\n                <form role=\"form\">\n                  <div class=\"box-body\">\n                    <div class=\"form-group\">\n                      <label for=\"jobTitle\">Job title</label>\n                      <input #jobName type=\"text\" class=\"form-control\"  placeholder=\"Job title\">\n                    </div>\n                     \n                  </div><!-- /.box-body -->\n\n                  <div class=\"box-footer\">\n                    <button type=\"button\" class=\"btn btn-primary\" (click)=\"AddJobTitle(jobName.value)\">Submit</button>\n                  </div>\n                </form>\n              </div><!-- /.box -->\n           \n              <!-- Input addon -->\n              \n\n            </div><!--/.col (left) -->\n            <!-- right column -->\n            \n          </div>\n           \n          <div class=\"row\">\n            <div class=\"col-xs-12\">\n              <div class=\"box\">\n                <div class=\"box-header\">\n                  <h3 class=\"box-title\">Jobs</h3>\n                  <div class=\"box-tools\">\n                    <div class=\"input-group\">\n                      <!--<input type=\"text\" name=\"table_search\" class=\"form-control input-sm pull-right\" style=\"width: 150px;\" placeholder=\"Search\">\n                      <div class=\"input-group-btn\">\n                        <button class=\"btn btn-sm btn-default\"><i class=\"fa fa-search\"></i></button>\n                      </div>-->\n                    </div>\n                  </div>\n                </div><!-- /.box-header -->\n                <div class=\"box-body table-responsive no-padding\">\n                  <table class=\"table table-hover\">\n                    <tbody><tr>\n                      <th>Job title</th>\n                      <th>Edit</th>\n                      <th>Delete</th>\n                    </tr>\n                    <tr *ngFor=\"let jobs of data\">\n                      <td>{{jobs.jobTitle}}</td>\n                      <td> <button type=\"button\" class=\"btn btn-sm btn-default\" data-toggle=\"modal\" data-target=\"#myModal\" (click)=\"jobNameedit.value=jobs.jobTitle;jobNameeditid.value=jobs.jobId\">Edit</button></td>\n                      <td><button type=\"button\" class=\"btn btn-sm btn-default\" (click)=\"DeleteJob(jobs.jobId)\">Delete</button></td>\n                    </tr>\n                   \n                  </tbody></table>\n                </div><!-- /.box-body -->\n              </div><!-- /.box -->\n            </div>\n          </div>      \n          \n        </section><!-- /.content -->\n      </div><!-- /.content-wrapper -->\n      <footer class=\"main-footer\">\n        <div class=\"pull-right hidden-xs\">\n          <b>Version</b> 2.0\n        </div>\n        <strong>Copyright &copy; 2014-2015 <a href=\"http://almsaeedstudio.com\">Almsaeed Studio</a>.</strong> All rights reserved.\n      </footer>\n    </div><!-- ./wrapper -->\n\n \n\n  <!-- Modal -->\n  <div class=\"modal fade\" id=\"myModal\" role=\"dialog\">\n    <div class=\"modal-dialog\">\n    \n      <!-- Modal content-->\n      <div class=\"modal-content\">\n        <div class=\"modal-header\">\n          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n          <h4 class=\"modal-title\">Edit</h4>\n        </div>\n        <div class=\"modal-body\">\n          <div class=\"box-body\">\n            <div class=\"form-group\">\n               <label for=\"jobTitle\">Job title</label>\n               <input #jobNameedit type=\"text\" class=\"form-control\"  placeholder=\"\">\n               <input #jobNameeditid type=\"text\" hidden>\n            </div>\n                     \n          </div><!-- /.box-body -->\n        </div>\n        <div class=\"modal-footer\">\n          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" (click)=\"EditJob(jobNameeditid.value,jobNameedit.value)\">Done</button>\n        </div>\n      </div>\n      \n    </div>\n  </div>\n  \n    \n"

/***/ }),

/***/ "./src/app/job-title/job-title.component.scss":
/*!****************************************************!*\
  !*** ./src/app/job-title/job-title.component.scss ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2pvYi10aXRsZS9qb2ItdGl0bGUuY29tcG9uZW50LnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/job-title/job-title.component.ts":
/*!**************************************************!*\
  !*** ./src/app/job-title/job-title.component.ts ***!
  \**************************************************/
/*! exports provided: JobTitleComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JobTitleComponent", function() { return JobTitleComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _job_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../job-api.service */ "./src/app/job-api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");




var JobTitleComponent = /** @class */ (function () {
    function JobTitleComponent(api, router) {
        this.api = api;
        this.router = router;
        //public data: Observable<Array<jobtitle>>;
        this.data = [];
    }
    JobTitleComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.api.getjobs().subscribe(function (res) { _this.data = res; });
    };
    JobTitleComponent.prototype.AddJobTitle = function (job) {
        var _this = this;
        console.log(job);
        var newJob = { jobTitle: job, jobId: 0 };
        this.api.addJob(newJob).subscribe(function (res) { return _this.data = res; });
    };
    JobTitleComponent.prototype.DeleteJob = function (id) {
        var _this = this;
        var conf = confirm("Are you want to delete this job!");
        if (conf == true) {
            this.api.deleteJob(id).subscribe(function (res) { return _this.data = res; });
        }
    };
    JobTitleComponent.prototype.EditJob = function (id, job) {
        var _this = this;
        var edited = { jobTitle: job, jobId: id };
        var rs = this.api.EditJob(edited).subscribe(function (res) { return _this.data = res; });
        console.log(rs);
    };
    JobTitleComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-job-title',
            template: __webpack_require__(/*! ./job-title.component.html */ "./src/app/job-title/job-title.component.html"),
            styles: [__webpack_require__(/*! ./job-title.component.scss */ "./src/app/job-title/job-title.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_job_api_service__WEBPACK_IMPORTED_MODULE_2__["JobApiService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], JobTitleComponent);
    return JobTitleComponent;
}());



/***/ }),

/***/ "./src/app/login.component.html":
/*!**************************************!*\
  !*** ./src/app/login.component.html ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<body class=\"login-page\">\n<div class=\"login-box\">\n      <div class=\"login-logo\">\n        <a href=\"../../index2.html\"><b>Admin</b>LTE</a>\n      </div><!-- /.login-logo -->\n      <div class=\"login-box-body\">\n        <p class=\"login-box-msg\">Sign in to start your session</p>\n        <form action=\"../../index2.html\" method=\"post\">\n          <div class=\"form-group has-feedback\">\n            <input type=\"text\" class=\"form-control\" placeholder=\"Email\"/>\n            <span class=\"glyphicon glyphicon-envelope form-control-feedback\"></span>\n          </div>\n          <div class=\"form-group has-feedback\">\n            <input type=\"password\" class=\"form-control\" placeholder=\"Password\"/>\n            <span class=\"glyphicon glyphicon-lock form-control-feedback\"></span>\n          </div>\n          <div class=\"row\">\n            <div class=\"col-xs-8\">    \n              <div class=\"checkbox icheck\">\n                <label>\n                  <input type=\"checkbox\"> Remember Me\n                </label>\n              </div>                        \n            </div><!-- /.col -->\n            <div class=\"col-xs-4\">\n              <button type=\"button\" class=\"btn btn-primary btn-block btn-flat\" (click)=\"signin()\">Sign In</button>\n            </div><!-- /.col -->\n          </div>\n        </form>\n\n\n        <a href=\"#\">I forgot my password</a><br>\n        <a routerLink=\"/register\" class=\"text-center\">Register a new client</a>\n\n      </div><!-- /.login-box-body -->\n    </div><!-- /.login-box -->\n</body>\n"

/***/ }),

/***/ "./src/app/login.component.scss":
/*!**************************************!*\
  !*** ./src/app/login.component.scss ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xvZ2luLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/login.component.ts":
/*!************************************!*\
  !*** ./src/app/login.component.ts ***!
  \************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var LoginComponent = /** @class */ (function () {
    function LoginComponent(router) {
        this.router = router;
        this.title = 'clientview';
    }
    ;
    LoginComponent.prototype.signin = function () {
        this.router.navigate(['/department']);
    };
    LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.component.html */ "./src/app/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.scss */ "./src/app/login.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/registerform/registerform.component.html":
/*!**********************************************************!*\
  !*** ./src/app/registerform/registerform.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = " <body class=\"register-page\">\n<div class=\"register-box\">\n      <div class=\"register-logo\">\n        <a href=\"../../index2.html\"><b>Admin</b>LTE</a>\n      </div>\n\n      <div class=\"register-box-body\">\n        <p class=\"login-box-msg\">Register a new membership</p>\n        <form action=\"../../index.html\" method=\"post\">\n          <div class=\"form-group has-feedback\">\n            <input type=\"text\" class=\"form-control\" placeholder=\"Full name\"/>\n            <span class=\"glyphicon glyphicon-user form-control-feedback\"></span>\n          </div>\n          <div class=\"form-group has-feedback\">\n            <input type=\"text\" class=\"form-control\" placeholder=\"Email\"/>\n            <span class=\"glyphicon glyphicon-envelope form-control-feedback\"></span>\n          </div>\n          <div class=\"form-group has-feedback\">\n            <input type=\"password\" class=\"form-control\" placeholder=\"Password\"/>\n            <span class=\"glyphicon glyphicon-lock form-control-feedback\"></span>\n          </div>\n          <div class=\"form-group has-feedback\">\n            <input type=\"password\" class=\"form-control\" placeholder=\"Retype password\"/>\n            <span class=\"glyphicon glyphicon-log-in form-control-feedback\"></span>\n          </div>\n          <div class=\"row\">\n            <div class=\"col-xs-8\">    \n              <div class=\"checkbox icheck\">\n                <label>\n                  <input type=\"checkbox\"> I agree to the <a href=\"#\">terms</a>\n                </label>\n              </div>                        \n            </div><!-- /.col -->\n            <div class=\"col-xs-4\">\n              <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat\">Register</button>\n            </div><!-- /.col -->\n          </div>\n        </form>        \n\n\n        <a routerLink=\"/login\" class=\"text-center\">I already have a membership</a>\n      </div><!-- /.form-box -->\n    </div><!-- /.register-box -->\n    </body>"

/***/ }),

/***/ "./src/app/registerform/registerform.component.scss":
/*!**********************************************************!*\
  !*** ./src/app/registerform/registerform.component.scss ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlZ2lzdGVyZm9ybS9yZWdpc3RlcmZvcm0uY29tcG9uZW50LnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/registerform/registerform.component.ts":
/*!********************************************************!*\
  !*** ./src/app/registerform/registerform.component.ts ***!
  \********************************************************/
/*! exports provided: RegisterformComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterformComponent", function() { return RegisterformComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var RegisterformComponent = /** @class */ (function () {
    function RegisterformComponent() {
    }
    RegisterformComponent.prototype.ngOnInit = function () {
    };
    RegisterformComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-registerform',
            template: __webpack_require__(/*! ./registerform.component.html */ "./src/app/registerform/registerform.component.html"),
            styles: [__webpack_require__(/*! ./registerform.component.scss */ "./src/app/registerform/registerform.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], RegisterformComponent);
    return RegisterformComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! hammerjs */ "./node_modules/hammerjs/hammer.js");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\hp\source\repos\ang\ang\clientview\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map